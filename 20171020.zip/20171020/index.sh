# !/usr/bin/env python
python3 indexer.py $1 $2 $3